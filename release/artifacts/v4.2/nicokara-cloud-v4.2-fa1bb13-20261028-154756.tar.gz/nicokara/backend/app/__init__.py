"""ニコカラ generator backend package."""

