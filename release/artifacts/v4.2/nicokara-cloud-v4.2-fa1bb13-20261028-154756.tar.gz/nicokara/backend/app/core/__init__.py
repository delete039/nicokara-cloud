"""Core configuration and persistence."""

