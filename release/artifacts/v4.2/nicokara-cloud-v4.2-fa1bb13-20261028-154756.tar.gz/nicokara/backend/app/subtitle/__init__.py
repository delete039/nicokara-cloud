"""ASS subtitle generation."""
