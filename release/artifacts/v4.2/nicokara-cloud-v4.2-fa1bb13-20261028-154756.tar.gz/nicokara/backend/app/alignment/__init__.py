"""Lyric-to-audio alignment."""

