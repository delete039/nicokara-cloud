from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class JobResponse(BaseModel):
    model_config = ConfigDict(extra="ignore")

    id: str
    status: str
    stage: str
    progress: int
    original_video_name: str
    video_size_bytes: int
    video_sha256: str
    lyrics_source: str | None = None
    vocal_mode: str = "on"
    alignment_mode: str = "auto"
    off_vocal_conversion: bool = False
    instrumental_ready: bool = False
    has_timeline: bool = False
    render_pending: bool = False
    available_vocal_modes: list[str] = Field(default_factory=list)
    render_vocal_mode: str | None = None
    client_submission_id: str | None = None
    input_mode: str = "VIDEO"
    source_upload_size_bytes: int | None = None
    source_upload_sha256: str | None = None
    error_code: str | None = None
    error_message: str | None = None
    queue_position: int | None = None
    queue_size: int | None = None
    created_at: datetime
    updated_at: datetime


class ReadingTokenReview(BaseModel):
    surface: str = Field(min_length=1)
    reading: str


class ReadingLineReview(BaseModel):
    surface: str = Field(min_length=1)
    tokens: list[ReadingTokenReview] = Field(min_length=1)


class ReadingReviewRequest(BaseModel):
    lines: list[ReadingLineReview] = Field(min_length=1)


class UploadTicketCreate(BaseModel):
    video_name: str
    video_size_bytes: int
    client_submission_id: str | None = None


class UploadTicketResponse(BaseModel):
    id: str
    status: str
    video_name: str
    video_size_bytes: int
    client_submission_id: str | None = None
    job_id: str | None = None
    queue_position: int | None = None
    queue_size: int | None = None
    created_at: datetime
    updated_at: datetime


class UploadChunkSessionCreate(BaseModel):
    video_name: str
    video_size_bytes: int
    chunk_size_bytes: int
    total_chunks: int


class UploadChunkSessionResponse(BaseModel):
    ticket_id: str
    status: str
    chunk_size_bytes: int
    total_chunks: int
    received_chunks: int
    received_chunk_indices: list[int] = Field(default_factory=list)
    missing_chunk_indices: list[int] = Field(default_factory=list)


class UploadChunkResponse(BaseModel):
    ticket_id: str
    chunk_index: int
    received_chunks: int
    total_chunks: int


class AudioUploadSessionCreate(BaseModel):
    audio_name: str
    audio_size_bytes: int
    original_video_name: str
    original_video_size_bytes: int
    chunk_size_bytes: int
    total_chunks: int
    client_submission_id: str


class AudioUploadSessionResponse(BaseModel):
    ticket_id: str
    status: str
    chunk_size_bytes: int
    total_chunks: int
    received_chunks: int
    received_chunk_indices: list[int]
    missing_chunk_indices: list[int]


class HealthResponse(BaseModel):
    status: str

